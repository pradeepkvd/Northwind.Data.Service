﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;

namespace ClaimsAppOIDC.Pages
{
    [Authorize]
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {
            var userName = User.Identity.Name;

            var authType = User.Identity.AuthenticationType;

            var isAdmin = User.IsInRole("Domain Admins");

            var hasAdminClaim = User.HasClaim("http://schemas.microsoft.com/ws/2008/06/identity/claims/role", "Domain Admins");

            var hasSomeClaim = User.HasClaim(ClaimTypes.Role, "Domain Admins");
        }
    }
}
